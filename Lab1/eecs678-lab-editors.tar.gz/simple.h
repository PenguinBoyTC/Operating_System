#ifndef __SIMPLE_H__
#define __SIMPLE_H__

#define COSINE_ONE 	45.0
#define COSINE_TWO 	0
#define LOOP_NUM 	10000
#define PRINT_NUM 	30

#endif /* __SIMPLE_H__ */
